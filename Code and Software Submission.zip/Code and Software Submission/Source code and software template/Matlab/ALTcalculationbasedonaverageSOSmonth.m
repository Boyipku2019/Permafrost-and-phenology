clear all;
clc;close all;

%打开DDT文件
fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalDDT1982-2020basedonSOSmonth.raw','r'); %打RAW文件
DDT = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
DDT=reshape(DDT,[1440,226,39]);





%打开LULC文件
IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
LULC=IGBP';

%设置ALT文件矩阵
ALT19822020=single(zeros(1440,226,39));

for i=1:1440
    for j=1:226
        %The mean edaphic factor of forests (1-5), open shrublands (6-7), savannas (8-9), grasslands (10), and permafrost wetlands (11) is 0.046, 0.050, 0.047, 0.033, and 0.064, respectively.
        %首先确定系数
        index=0;
        switch LULC(i,j+25)
            case{1,2,3,4,5}
            index=0.046;
            case{6,7}
            index=0.050;
            case{8,9}
            index=0.047;
            case{10}
            index=0.033;
            case{11}
            index=0.064;
            otherwise
            ALT19822020(i,j,:)=NaN;%非自然植被像元统一设置为无效-1
        end
        
        for year=1:39
           ALT19822020(i,j,year)=sqrt(DDT(i,j,year))* index;
            
        end
    end
    i
end
%保存
fid=fopen('D:\globalALT1982-2020.raw','wb');%存为raw
fwrite(fid,ALT19822020,'float');
fclose(fid);


