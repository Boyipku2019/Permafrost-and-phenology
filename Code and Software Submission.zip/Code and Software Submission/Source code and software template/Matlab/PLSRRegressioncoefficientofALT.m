clear all;close all;
clc;

%读取用地类型数据

IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 

%读取ALT数据
ALT=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalALT1982-2020.raw','r'); %打RAW文件
ALT = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALT=reshape(ALT,[1440,226,39]);

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);

%读取最佳区间数据
SMandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\SMandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
SMandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMandGUDpartialcorrelationpreseasonlength=reshape(SMandGUDpartialcorrelationpreseasonlength,[1440,226,25]);

%读取最佳区间数据
TandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\TandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
TandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
fclose(fid); % 关闭文件
TandGUDpartialcorrelationpreseasonlength=reshape(TandGUDpartialcorrelationpreseasonlength,[1440,226,25]);



%读取最佳区间数据
PandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\PandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
PandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
fclose(fid); % 关闭文件
PandGUDpartialcorrelationpreseasonlength=reshape(PandGUDpartialcorrelationpreseasonlength,[1440,226,25]);


%读取最佳区间数据
RandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\RandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
RandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
fclose(fid); % 关闭文件
RandGUDpartialcorrelationpreseasonlength=reshape(RandGUDpartialcorrelationpreseasonlength,[1440,226,25]);



%读取SPEI数据
SPEIpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason0.raw','r'); %打RAW文件
SPEIpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason0=reshape(SPEIpreseason0,[1440,226,39]);

SPEIpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason1.raw','r'); %打RAW文件
SPEIpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason1=reshape(SPEIpreseason1,[1440,226,39]);

SPEIpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason2.raw','r'); %打RAW文件
SPEIpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason2=reshape(SPEIpreseason2,[1440,226,39]);

SPEIpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason3.raw','r'); %打RAW文件
SPEIpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason3=reshape(SPEIpreseason3,[1440,226,39]);

%读取SM数据
SMpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason0.raw','r'); %打RAW文件
SMpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason0=reshape(SMpreseason0,[1440,226,39]);

SMpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason1.raw','r'); %打RAW文件
SMpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason1=reshape(SMpreseason1,[1440,226,39]);

SMpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason2.raw','r'); %打RAW文件
SMpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason2=reshape(SMpreseason2,[1440,226,39]);

SMpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason3.raw','r'); %打RAW文件
SMpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason3=reshape(SMpreseason3,[1440,226,39]);

%读取T数据
Tpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason0.raw','r'); %打RAW文件
Tpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason0=reshape(Tpreseason0,[1440,226,39]);

% fid=fopen('D:\Tpreseason0test.raw','wb');%存为raw
% fwrite(fid,Tpreseason0,'single');
% fclose(fid); 

Tpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason1.raw','r'); %打RAW文件
Tpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason1=reshape(Tpreseason1,[1440,226,39]);

Tpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason2.raw','r'); %打RAW文件
Tpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason2=reshape(Tpreseason2,[1440,226,39]);

Tpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason3.raw','r'); %打RAW文件
Tpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason3=reshape(Tpreseason3,[1440,226,39]);

%读取P数据
Ppreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason0.raw','r'); %打RAW文件
Ppreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason0=reshape(Ppreseason0,[1440,226,39]);

Ppreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason1.raw','r'); %打RAW文件
Ppreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason1=reshape(Ppreseason1,[1440,226,39]);

Ppreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason2.raw','r'); %打RAW文件
Ppreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason2=reshape(Ppreseason2,[1440,226,39]);

Ppreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason3.raw','r'); %打RAW文件
Ppreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason3=reshape(Ppreseason3,[1440,226,39]);

%读取R数据
Rpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason0.raw','r'); %打RAW文件
Rpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason0=reshape(Rpreseason0,[1440,226,39]);

Rpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason1.raw','r'); %打RAW文件
Rpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason1=reshape(Rpreseason1,[1440,226,39]);

Rpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason2.raw','r'); %打RAW文件
Rpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason2=reshape(Rpreseason2,[1440,226,39]);

Rpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason3.raw','r'); %打RAW文件
Rpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason3=reshape(Rpreseason3,[1440,226,39]);



%存储模型拟合的各种参数

ENFfactorimportance=[];
DNFfactorimportance=[];
DBFfactorimportance=[];
MFfactorimportance=[];
SHLfactorimportance=[];
SVAfactorimportance=[];
GRAfactorimportance=[];
WETfactorimportance=[];
%标准差，作图用
ENFfactorimportancestd=[];
DNFfactorimportancestd=[];
DBFfactorimportancestd=[];
MFfactorimportancestd=[];
SHLfactorimportancestd=[];
SVAfactorimportancestd=[];
GRAfactorimportancestd=[];
WETfactorimportancestd=[];


for year=1:25
    ENFX=[];ENFY=[];ENFFI=[];ENFR2=[];
    DNFX=[];DNFY=[];DNFFI=[];
    DBFX=[];DBFY=[];DBFFI=[];
    MFX=[];MFY=[];MFFI=[];
    SHLX=[];SHLY=[];SHLFI=[];
    SVAX=[];SVAY=[];SVAFI=[];
    GRAX=[];GRAY=[];GRAFI=[];
    WETX=[];WETY=[];WETFI=[];
count=0;
countENF=0;countDNF=0;countDBF=0;countMF=0;countSHL=0;countSVA=0;countGRA=0;countWET=0;
    for i=1:1440
        for j=1:226
         if ~isnan(GUDall(i,j,1))&&SPEIpreseason0(i,j,1)~=0&&SMpreseason0(i,j,1)~=0&&Tpreseason0(i,j,1)~=0&&Ppreseason0(i,j,1)~=0&&Rpreseason0(i,j,1)~=0  %判断为有效像元，去除无效物候数据和0值环境变量数据
             SPEIonepixel=single(zeros(15,4));%1到4列分别存储0-3preseason变量
            
             GUDonepixel=GUDall(i,j,year:year+14);
             GUDonepixel=reshape(GUDonepixel,15,1);
             
%                         SPEIonepixel(:,1)=reshape(SPEIpreseason0(i,j,year:year+14),15,1);
%              SPEIonepixel(:,2)=reshape(SPEIpreseason1(i,j,year:year+14),15,1);
%              SPEIonepixel(:,3)=reshape(SPEIpreseason2(i,j,year:year+14),15,1);
%              SPEIonepixel(:,4)=reshape(SPEIpreseason3(i,j,year:year+14),15,1);
             
                        SMonepixel(:,1)=reshape(SMpreseason0(i,j,year:year+14),15,1);
             SMonepixel(:,2)=reshape(SMpreseason1(i,j,year:year+14),15,1);
             SMonepixel(:,3)=reshape(SMpreseason2(i,j,year:year+14),15,1);
             SMonepixel(:,4)=reshape(SMpreseason3(i,j,year:year+14),15,1);
             
                       Tonepixel(:,1)=reshape(Tpreseason0(i,j,year:year+14),15,1);
             Tonepixel(:,2)=reshape(Tpreseason1(i,j,year:year+14),15,1);
             Tonepixel(:,3)=reshape(Tpreseason2(i,j,year:year+14),15,1);
             Tonepixel(:,4)=reshape(Tpreseason3(i,j,year:year+14),15,1);

                       Ponepixel(:,1)=reshape(Ppreseason0(i,j,year:year+14),15,1);
             Ponepixel(:,2)=reshape(Ppreseason1(i,j,year:year+14),15,1);
             Ponepixel(:,3)=reshape(Ppreseason2(i,j,year:year+14),15,1);
             Ponepixel(:,4)=reshape(Ppreseason3(i,j,year:year+14),15,1);
             
                       Ronepixel(:,1)=reshape(Rpreseason0(i,j,year:year+14),15,1);
             Ronepixel(:,2)=reshape(Rpreseason1(i,j,year:year+14),15,1);
             Ronepixel(:,3)=reshape(Rpreseason2(i,j,year:year+14),15,1);
             Ronepixel(:,4)=reshape(Rpreseason3(i,j,year:year+14),15,1);
             
             
             %ALT只有3个月的，不然没有意义
             ALTonepixel=reshape(ALT(i,j,year:year+14),15,1);
             y=GUDonepixel;
             x=[SMonepixel(:,SMandGUDpartialcorrelationpreseasonlength(i,j,year)+1),Tonepixel(:,TandGUDpartialcorrelationpreseasonlength(i,j,year)+1),Ponepixel(:,PandGUDpartialcorrelationpreseasonlength(i,j,year)+1),Ronepixel(:,RandGUDpartialcorrelationpreseasonlength(i,j,year)+1),ALTonepixel(:)];
                       if IGBP(i,j+25)==1
                           ENFX=[ENFX;x];
                           ENFY=[ENFY;y];
                                               %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                    if sum(Y== 0) < 1
                                     % 使用 PLSR
                                [XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

                                % XL 和 YL 是载荷矩阵
                                % XS 和 YS 是得分矩阵
                                % BETA 是回归系数
                                % PCTVAR 解释了每个成分的方差百分比
                                % MSE 是均方误差
                                % stats 提供了一些统计信息

                                % 使用 BETA 来做预测
                                Y_pred = [ones(size(X,1),1) X] * BETA;

                                % 计算 R²
                                SS_tot = sum((Y - mean(Y)).^2);
                                SS_res = sum((Y - Y_pred).^2);
                                R2 = 1 - SS_res / SS_tot;



                                % 分析每个自变量的重要性
                                % 一个简单的方法是查看 BETA(2:end) 的绝对值
                                factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    ENFFI=[ENFFI, BETA(2:6)];
                    countENF=countENF+1;
                    end
                          aa=0;             
                        %ENFR2=[ENFR2, R2];   
                    end
                       end
                       if IGBP(i,j+25)==3
                           DNFX=[DNFX;x];
                           DNFY=[DNFY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                    if all(diff(Y) == 0)~=1&&sum(Y== 0) < 1
                                       % 使用 PLSR
                    [XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

                    % XL 和 YL 是载荷矩阵
                    % XS 和 YS 是得分矩阵
                    % BETA 是回归系数
                    % PCTVAR 解释了每个成分的方差百分比
                    % MSE 是均方误差
                    % stats 提供了一些统计信息

                    % 使用 BETA 来做预测
                    Y_pred = [ones(size(X,1),1) X] * BETA;

                    % 计算 R²
                    SS_tot = sum((Y - mean(Y)).^2);
                    SS_res = sum((Y - Y_pred).^2);
                    R2 = 1 - SS_res / SS_tot;



                    % 分析每个自变量的重要性
                    % 一个简单的方法是查看 BETA(2:end) 的绝对值
                    factor_importance = abs(BETA(2:end));

                                        % 输出回归系数和 R^2 值
                                        %b的后5个回归系数对应的五个自变量
                                        if R2>0.7
                                        DNFFI=[DNFFI, BETA(2:6)]; countDNF=countDNF+1;
                                        end
                                              aa=0;   
                    end
                       end
                       if IGBP(i,j+25)==4
                           DBFX=[DBFX;x];
                           DBFY=[DBFY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 count=count+1;
                                xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                    if sum(Y== 0) < 1
                                      % 使用 PLSR
[XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    DBFFI=[DBFFI, BETA(2:6)]; countDBF=countDBF+1;
                    end
                          aa=0;     
                    end
                       end
                       if IGBP(i,j+25)==5
                           MFX=[MFX;x];
                           MFY=[MFY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                  xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                    if sum(Y== 0) < 1
                    % 为岭回归添加常数项
                   [XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    MFFI=[MFFI, BETA(2:6)]; countMF=countMF+1;
                    end
                          aa=0; 
                       end
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHLX=[SHLX;x];
                           SHLY=[SHLY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                   xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
              if sum(Y== 0) < 1       
                                      % 使用 PLSR
[XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    SHLFI=[SHLFI, BETA(2:6)]; countSHL=countSHL+1;
                    end
                          aa=0; 
              end
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVAX=[SVAX;x];
                           SVAY=[SVAY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                  xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                     if sum(Y== 0) < 1
                                       % 使用 PLSR
[XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    SVAFI=[SVAFI, BETA(2:6)]; countSVA=countSVA+1;
                    end
                          aa=0;  
                     end
                       end
                       if IGBP(i,j+25)==10
                           GRAX=[GRAX;x];
                           GRAY=[GRAY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                     if sum(Y== 0) < 1
                   % 使用 PLSR
[XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    GRAFI=[GRAFI, BETA(2:6)]; countGRA=countGRA+1;
                    end
                          aa=0; 
                     end
                       end
                       if IGBP(i,j+25)==11
                           WETX=[ENFX;x];
                           WETY=[ENFY;y];
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                Y=y;X=x;
                     if sum(Y== 0) < 1
                   % 假设 X 是一个 n×p 矩阵，n 是观测值数量，p 是自变量的数量


% 使用 PLSR
[XL, YL, XS, YS, BETA, PCTVAR, MSE, stats] = plsregress(X, Y, 5);

% XL 和 YL 是载荷矩阵
% XS 和 YS 是得分矩阵
% BETA 是回归系数
% PCTVAR 解释了每个成分的方差百分比
% MSE 是均方误差
% stats 提供了一些统计信息

% 使用 BETA 来做预测
Y_pred = [ones(size(X,1),1) X] * BETA;

% 计算 R²
SS_tot = sum((Y - mean(Y)).^2);
SS_res = sum((Y - Y_pred).^2);
R2 = 1 - SS_res / SS_tot;



% 分析每个自变量的重要性
% 一个简单的方法是查看 BETA(2:end) 的绝对值
factor_importance = abs(BETA(2:end));


                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    WETFI=[WETFI, BETA(2:6)]; countWET=countWET+1;
                    end
                          aa=0;  
                     end
                       end
           
            end
        end
        year,i
    end
   
   aaa=0;
   ENFfactorimportance=[ENFfactorimportance,mean(ENFFI,2)];
   DNFfactorimportance=[DNFfactorimportance,mean(DNFFI,2)];
   DBFfactorimportance=[DBFfactorimportance,mean(DBFFI,2)];
   MFfactorimportance=[MFfactorimportance,mean(MFFI,2)];
   SHLfactorimportance=[SHLfactorimportance,mean(SHLFI,2)];
   SVAfactorimportance=[SVAfactorimportance,mean(SVAFI,2)];
   GRAfactorimportance=[GRAfactorimportance,mean(GRAFI,2)];
   WETfactorimportance=[WETfactorimportance,mean(WETFI,2)];
   
   
   
   ENFfactorimportancestd=[ENFfactorimportancestd,std(ENFFI,0,2)];
   DNFfactorimportancestd=[DNFfactorimportancestd,std(DNFFI,0,2)];
   DBFfactorimportancestd=[DBFfactorimportancestd,std(DBFFI,0,2)];
   MFfactorimportancestd=[MFfactorimportancestd,std(MFFI,0,2)];
   SHLfactorimportancestd=[SHLfactorimportancestd,std(SHLFI,0,2)];
   SVAfactorimportancestd=[SVAfactorimportancestd,std(SVAFI,0,2)];
   GRAfactorimportancestd=[GRAfactorimportancestd,std(GRAFI,0,2)];
   WETfactorimportancestd=[WETfactorimportancestd,std(WETFI,0,2)];
end


%1ENF
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,1)
y=ENFfactorimportance(5,:);x=(1:size(y,2));
% y=mean(ENFall2,'omitnan');
% e =std(ENFall2,'omitnan');

% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');


% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+5, minY-0.6, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('ENF');
legend([plot1, plot2],'Location', 'best');
ylim([-5.5 0])
% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([-20 5]);
% grid on;
% hold off;




%2DNF
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,2)
y=DNFfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+3, minY-1.1, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('DNF');
legend([plot1, plot2],'Location', 'best');
ylim([-7 0])

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%3DBF
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,3)
y=DBFfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+5, minY-0.035, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('DBF');
legend([plot1, plot2],'Location', 'best');

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%4MF
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,4)
y=MFfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+5, minY-0.5, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('MF');
legend([plot1, plot2],'Location', 'best');

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%5SHL
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,5)
y=SHLfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+7, minY+0.2, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('SHL');
legend([plot1, plot2],'Location', 'best');

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%6SVA
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,6)
y=SVAfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% % 计算显著性水平
% p_left = anova1(y_left, x_left, 'off');
% p_right = anova1(y_right, x_right, 'off');
% % 主y轴
% yyaxis left;

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);

aa=0;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+10, minY-0.4, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('WDL');
legend([plot1, plot2],'Location', 'best');
ylim([-4.5 -1])
% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%7GRA
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,7)
y=GRAfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+7, minY-1.4, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('GRA');
legend([plot1, plot2],'Location', 'best');

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;



%8WET
% % t=tiledlayout(1,1,'TileSpacing','none');
% % nexttile;
subplot(2,4,8)
y=WETfactorimportance(5,:);x=(1:size(y,2));


% 找出散点中的最小值及其索引
[minY, minIndex] = min(y);
minX = x(minIndex);

% 在最小值点左右分别进行线性回归
x_left = x(1:minIndex);
y_left = y(1:minIndex);
x_right = x(minIndex:end);
y_right = y(minIndex:end);

% 线性回归左侧数据
coeff_left = polyfit(x_left, y_left, 1);
y_fit_left = polyval(coeff_left, x_left);

% 线性回归右侧数据
coeff_right = polyfit(x_right, y_right, 1);
y_fit_right = polyval(coeff_right, x_right);

% 计算 R2 值
r2_left = 1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2);
r2_right = 1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2);

% 计算显著性水平
p_left = anova1(y_left, x_left, 'off');
p_right = anova1(y_right, x_right, 'off');

% 进行一元线性回归
lm = fitlm(x_left, y_left, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_left = coefInfo.pValue(2);


% 进行一元线性回归
lm = fitlm(x_right, y_right, 'linear');

% 显示回归模型的摘要，包括显著性检验
disp(lm);

% 获取关于回归系数的统计信息
coefInfo = lm.Coefficients;
p_right = coefInfo.pValue(2);
% % 主y轴
% yyaxis left;

scatter(x, y, 'o', 'DisplayName', 'Data Points');
hold on;

% 在图例中用星号标注两个线性回归的增减趋势是否显著
legend('Location', 'best');


xticks([1 7 13 19 25])
xticklabels({'1982-1996', '1988-2002', '1994-2008', '2000-2014', '2006-2020'})
xtickangle(30) 
% % 绘制灰色柱状图
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'Bar Plot Data Y');
% ylabel('Data Y Bar Plot');
% 
% grid on;
% hold off;
% % 次y轴
% yyaxis right;
% 根据显著性水平添加星号
stars_left = addStars(p_left);
stars_right = addStars(p_right);
% 标注最小点
plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
text1=text(minX+7, minY-0.5, sprintf('Tipping period: %d - %d', minX+1981,minX+1981+14), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');

plot1=plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), r2_left, stars_left));
plot2=plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), r2_right, stars_right));
ylabel('Regression coefficient of ALT');

title('WET');
legend([plot1, plot2],'Location', 'best');

% % 次y轴
% yyaxis right;
% % 绘制灰色柱状图
% y=mean(ENFall2preseasonlength,'omitnan');
% bar(x, y, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none', 'DisplayName', 'essential ALT period');
% ylabel('Preseason length');
% ylim([0 6]);
% grid on;
% hold off;


% 
% 添加星号的辅助函数
function stars = addStars(p)
    if p < 0.001
        stars = '***';
    elseif p < 0.01
        stars = '**';
    elseif p < 0.05
        stars = '*';
    else
        stars = '';
    end
end